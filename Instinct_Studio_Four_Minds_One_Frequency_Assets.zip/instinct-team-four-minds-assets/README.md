# Instinct Studio: Four Minds. One Frequency.

This package contains the approved team-section maquette and named graphic elements extracted from it.

## Important

The generated portrait crops are composition references only. The production website must use the real Dominique Soucy, Stefan Szary, Neil Frisby and Youri Hainz portraits already stored in the repository.

## Folders

- `00-maquette/`: complete visual reference.
- `01-profile-compositions/`: one layout reference per person.
- `02-cinematic-elements/`: film frames, paper fragments and visual textures.
- `03-creative-text-elements/`: handwritten notes and small graphic statements.
- `04-signal-elements/`: blue signal and frequency references.
- `05-reference/`: asset manifest, contact sheet and integration notes.

## Production rules

- Use real portraits from the repository.
- Keep names, roles and essential descriptions as live HTML.
- Treat supplied handwritten text crops as decorative graphics with `aria-hidden="true"`.
- Rebuild blue connections with SVG or canvas for animation.
- Do not display the full maquette as the production section.
