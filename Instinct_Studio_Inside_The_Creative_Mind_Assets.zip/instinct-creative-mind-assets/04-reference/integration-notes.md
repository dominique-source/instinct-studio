# Integration notes

## Desktop

Recreate the maquette as a layered responsive section. Use live HTML for the headline, the central INSTINCT word, stage numbers, stage names and descriptions. Use the supplied PNGs for film stills, paper elements, storyboards and handwritten notes.

## Motion

- Draw the electric-blue path progressively as the visitor scrolls.
- Reveal each stage in sequence.
- Give paper notes a subtle 2 to 4 degree rotation.
- Add a small depth shift to film stills.
- Keep motion under 700 ms for individual reveals.
- Disable nonessential movement when reduced motion is requested.

## Mobile

Convert the composition to four vertical chapters. Keep INSTINCT pinned briefly near the top, then reveal Human Truth, Signal, Visual Language and Cultural Impact in sequence. Avoid shrinking the full desktop collage into an unreadable image.

## Accessibility

Graphic notes are decorative. Mark them aria-hidden. Repeat their meaning through concise live text or screen-reader-only text. Do not put essential navigation or controls inside image assets.
