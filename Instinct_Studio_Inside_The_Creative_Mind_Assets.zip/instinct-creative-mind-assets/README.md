# Instinct Studio: Inside the Creative Mind

This package contains the complete approved website-section mockup and named visual assets extracted from it.

## Folders

- `00-maquette/`: complete visual reference.
- `01-composition-blocks/`: large layout groups for recreating the section.
- `02-film-and-paper-elements/`: individual photographic, storyboard and paper elements.
- `03-creative-text-elements/`: handwritten notes and micro-copy treated as graphic assets.
- `04-reference/`: mapping and integration notes.

## Production use

- Keep the large title, stage names and descriptions as live HTML text.
- Use the graphic text elements as decorative images with `aria-hidden="true"`.
- Include an accessible text equivalent in the page structure.
- Place each asset over the existing black background. The crops retain the original texture and black field so they blend with the concept.
- Preserve the electric-blue connector line as CSS or SVG animation.
- Use the full maquette as the source of truth for hierarchy, spacing, overlap and direction.

## Core sequence

1. Human Truth
2. Signal
3. Visual Language
4. Cultural Impact

The word `INSTINCT` remains the visual nucleus.
